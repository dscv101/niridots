# MutedRetroSpace-Cursor (Builder)

This is a **cursor accent/theme** that matches your Muted Retro Space palette.
It ships with PNG sources and `.cfg` descriptors. Use `xcursorgen` to build.

## Build
```bash
# Dependencies
# Debian/Ubuntu: sudo apt install xcursorgen
# Arch: sudo pacman -Sxcursorgen (provided by xorg-xcursorgen)
# Fedora: sudo dnf install xcursorgen

# Build
cd MutedRetroSpace-Cursor
bash build.sh
```

## Install (user)
```bash
mkdir -p ~/.icons/MutedRetroSpace-Cursor
cp -r cursors index.theme ~/.icons/MutedRetroSpace-Cursor/

# Apply
gsettings set org.gnome.desktop.interface cursor-theme 'MutedRetroSpace-Cursor'
```

If your DE caches cursors, log out/in or restart your compositor.
