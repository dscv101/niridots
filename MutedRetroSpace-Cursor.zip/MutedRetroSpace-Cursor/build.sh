#!/usr/bin/env bash
set -euo pipefail
THEME_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$THEME_DIR/cursors"

if ! command -v xcursorgen >/dev/null 2>&1; then
  echo "xcursorgen is required. Install: sudo apt install xcursorgen (or your distro equivalent)."
  exit 1
fi

build_cursor () {
  local name="$1"
  xcursorgen "cfg/${name}.cfg" "cursors/${name}"
}

# Build main cursors
for c in left_ptr text pointer crosshair not-allowed wait progress ew-resize ns-resize nesw-resize nwse-resize move; do
  build_cursor "$c"
done

# Symlinks / aliases
cd "$THEME_DIR/cursors"
ln -sf left_ptr default
ln -sf left_ptr arrow
ln -sf pointer hand1
ln -sf pointer hand2
ln -sf ew-resize sb_h_double_arrow
ln -sf ns-resize sb_v_double_arrow
ln -sf nesw-resize fd_d009
ln -sf nwse-resize fd_d008
ln -sf text xterm
ln -sf not-allowed crossed_circle
echo "Build complete. Install to ~/.icons/MutedRetroSpace-Cursor and select it."
