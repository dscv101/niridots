# SDDM Theme — MutedRetroSpace-Minimal

Ultra-minimal SDDM layout with a centered compact login row, big clock, and text-only power actions.
Matches the Muted Retro Space palette used across your desktop.

## Install
```bash
sudo mkdir -p /usr/share/sddm/themes/MutedRetroSpace-Minimal
sudo cp -r SDDM-Theme-MutedRetroSpace-Minimal/* /usr/share/sddm/themes/MutedRetroSpace-Minimal/
```

## Enable
```bash
sudo mkdir -p /etc/sddm.conf.d
printf "[Theme]\nCurrent=MutedRetroSpace-Minimal\n" | sudo tee /etc/sddm.conf.d/theme.conf
```

## Configure background
Edit `/usr/share/sddm/themes/MutedRetroSpace-Minimal/theme.conf` and set:
```
[Settings]
Background=/path/to/your/muted-space-1920x1080.png
```
