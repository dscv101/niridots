# MutedRetroSpace — GTK Theme (Packaged)

A cohesive GTK theme that matches your Niri/Waybar/mako/wofi/Ghostty palette.

## Install

### User install
```bash
mkdir -p ~/.themes
cp -r MutedRetroSpace ~/.themes/
```
Then select it:
- **GNOME Tweaks** → Appearance → **Legacy Applications** = MutedRetroSpace
- Or via gsettings for GTK 3 apps:
```bash
gsettings set org.gnome.desktop.interface gtk-theme 'MutedRetroSpace'
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'
```
> Note: GTK 4 / Libadwaita apps largely ignore third‑party themes; our `gtk-4.0/gtk.css` provides lightweight overrides where permitted.

### System‑wide (optional)
```bash
sudo cp -r MutedRetroSpace /usr/share/themes/
```

## Components
- `gtk-3.0/gtk.css` — Full GTK 3 styling (buttons, headers, lists, menus, tooltips)
- `gtk-4.0/gtk.css` — Conservative GTK 4 overrides (Libadwaita respects dark scheme; accents applied where allowed)
- `gnome-shell/gnome-shell.css` — Minimal panel/popups accents (requires enabling via a Shell theme tool/extension)

## Suggested companions
- **Icons:** Papirus-Dark
- **Cursor:** Bibata-Modern-Ice
- **Fonts:** Inter UI (UI), JetBrainsMono Nerd Font (terminal)

## Palette
- Deep Teal #2E4A46
- Sage #8E9B8C
- Olive #9DAA8F
- Slate #4A5E5A
- Cream #F3EAD7
- Sand #E6D6A6
- Peach #E9B872
- Terra #B77C61
- Star Yellow #E8D39E
