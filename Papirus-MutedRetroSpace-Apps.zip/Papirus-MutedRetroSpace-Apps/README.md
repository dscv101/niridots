# Papirus-MutedRetroSpace-Apps

Additional app icons that match the **Muted Retro Space** palette.
This theme inherits `Papirus-MutedRetroSpace` and `Papirus-Dark`.

## Install
```bash
mkdir -p ~/.icons
cp -r Papirus-MutedRetroSpace-Apps ~/.icons/
gsettings set org.gnome.desktop.interface icon-theme 'Papirus-MutedRetroSpace-Apps'
```

## Provided glyphs
- **Terminal:** utilities-terminal, org.gnome.Terminal, foot, kitty, Alacritty, org.gnome.Console, wezterm, xfce4-terminal
- **Files:** system-file-manager, org.gnome.Nautilus, org.kde.dolphin, nemo, thunar
- **Browser:** web-browser, org.mozilla.firefox, firefox, chromium, google-chrome, org.gnome.Epiphany

Use `gnome-extensions appindicator` or your DE's icon inspector to confirm app-ids.
If a program uses a nonstandard ID, tell me and I'll add that alias.
