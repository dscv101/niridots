# Papirus-MutedRetroSpace (Overrides)

This icon theme inherits **Papirus-Dark** and overrides common folder/place icons
using the **Muted Retro Space** palette to match your Niri/Waybar/GTK theme.

## Install (user)
```bash
mkdir -p ~/.icons
cp -r Papirus-MutedRetroSpace ~/.icons/
# Select the theme (GNOME example):
gsettings set org.gnome.desktop.interface icon-theme 'Papirus-MutedRetroSpace'
```

## Install (override Papirus-Dark without switching theme)
> Advanced: drop the `scalable/places/*.svg` into:
> `~/.local/share/icons/Papirus-Dark/scalable/places/` (and matching size dirs)
> Then run: `gtk-update-icon-cache -f ~/.local/share/icons/Papirus-Dark`

## Notes
- Direct rasterized PNGs are unnecessary; modern desktops read SVG at any size.
- We provide common size directories for compatibility.
- Symbolic icons are simple outlines tuned for light-on-dark panels.
